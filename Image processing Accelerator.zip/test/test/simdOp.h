#pragma once

cv::Mat Convolution_simd(cv::Mat img, cv::Mat kernel);
